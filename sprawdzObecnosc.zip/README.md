# studentRecognition
This application is designed to recognize student presence during classes. All data are stored in mysql database.

Please keep this application with the same directory as uczniowie folder because otherwise the script will not work. Remember also to change mysql database access data w pliku mysqlConnect.py. Unfortunately you need to add images by yourself the name of images is nickname from database with .jpg extension.
Remember to import database to mysql. 
Default students and teachers are added so you can change how the program works

PL
Pamiętaj, aby aplikacja była trzymana w tej samej lokalizacji co folder uczniowie. Pamiętaj również, aby zmienić datę dostępu bazy danych mysql w pliku mysqlConnect.py. Niestety zdjęcia trzeba dodać ręcznie, nazwa tych zdjęc to nickname z bazy danych z rozszerzeniem .jpg. Pamiętaj zaimportować baze danych do mysql.
Defaltowi studenci oraz nauczyciele są dodani do bazy, tak aby można było sprawdzić jak działa program.
